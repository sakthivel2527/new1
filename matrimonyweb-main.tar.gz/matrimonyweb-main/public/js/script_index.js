const body = document.querySelector("body");
const darkLight = document.querySelector("#darkLight");
const sidebar = document.querySelector(".sidebar");
const submenuItems = document.querySelectorAll(".submenu_item");
const sidebarOpen = document.querySelector("#sidebarOpen");
const sidebarClose = document.querySelector(".collapse_sidebar");
const sidebarExpand = document.querySelector(".expand_sidebar");
const heartIcon = document.getElementById("heartIcon");
sidebarOpen.addEventListener("click", () => sidebar.classList.toggle("close"));

window.onload = function() {
  sidebar.classList.add("close", "hoverable");
};
sidebarClose.addEventListener("click", () => {
  sidebar.classList.add("close", "hoverable");
});

sidebarExpand.addEventListener("click", () => {
  sidebar.classList.remove("close", "hoverable");
});

sidebar.addEventListener("mouseenter", () => {
  if (sidebar.classList.contains("hoverable")) {
    sidebar.classList.remove("close");
  }
});
sidebar.addEventListener("mouseleave", () => {
  if (sidebar.classList.contains("hoverable")) {
    sidebar.classList.add("close");
  }
});

// darkLight.addEventListener("click", () => {
//   body.classList.toggle("dark");
//   if (body.classList.contains("dark")) {
//     document.setI;
//     darkLight.classList.replace("bx-sun", "bx-moon");
//   } else {
//     darkLight.classList.replace("bx-moon", "bx-sun");
//   }
// });

submenuItems.forEach((item, index) => {
  item.addEventListener("click", () => {
    item.classList.toggle("show_submenu");
    submenuItems.forEach((item2, index2) => {
      if (index !== index2) {
        item2.classList.remove("show_submenu");
      }
    });
  });
});

if (window.innerWidth < 768) {
  sidebar.classList.add("close");
} else {
  sidebar.classList.remove("close");
}

document.addEventListener('click', function(event) {
  // Check if the clicked element has the class "bx-heart"
  if (event.target.classList.contains('bx-heart')) {
      // Toggle the class name of the clicked heart icon
      event.target.classList.toggle('bx-heart');
      event.target.classList.toggle('bxs-heart');
  } else if (event.target.classList.contains('bxs-heart')) {
      // Toggle the class name of the clicked heart icon
      event.target.classList.toggle('bxs-heart');
      event.target.classList.toggle('bx-heart');
  }
});

const filtersTrigger = document.getElementById("filtersTrigger");
const filtersModal = document.getElementById("filtersModal");
const filtersClose = document.getElementById("filtersClose");

function showModal() {
    filtersModal.style.display = "block";
}
function hideModal() {
    filtersModal.style.display = "none";
}

filtersTrigger.addEventListener("click", showModal);
filtersClose.addEventListener("click", hideModal);
window.addEventListener("click", function(event) {
    if (event.target === filtersModal) {
        hideModal();
    }
});

// Get the modal element
var modal = document.getElementById("inviteFriendsModal");

// Get the button that opens the modal
var btn = document.getElementById("openModalBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}





